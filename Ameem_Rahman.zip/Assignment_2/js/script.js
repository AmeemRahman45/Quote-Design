  // Wait for user interaction to start audio
  function startAudio() {
    const audio = document.getElementById('bg-audio');
    audio.play();
    // Remove this listener after first play so it doesn't try again
    window.removeEventListener('click', startAudio);
  }

  // Listen for the first click anywhere on the page
  window.addEventListener('click', startAudio);